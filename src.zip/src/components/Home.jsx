import React from 'react'

const Home = () => {
  return (
    <h1 class="text-center mt-4">Welcome</h1>
  )
}

export default Home