import React from 'react';
import { Link} from 'react-router-dom';
import  { useState,useEffect } from 'react';
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';


const RejectedUsers = () => {
    const[registration,setRegistration]=useState([]);
  

    
        useEffect(() => {
            async function fetchRegistration() {
                try {
                    const response = await axios.get("http://localhost:8080/api/admin/rejectedusers");
                    setRegistration(response.data);
                } catch (error) {
                    console.error("Error fetching registrations:", error);
                }
            }
    
            fetchRegistration();
        }, []);
    
    
    
    
        // async function deleteRegistrationById(id) {
        //     try {
        //         await axios.delete(`http://localhost:8080/api/admin/${id}`);
        //         setRegistration(registration.filter(registration => registration.id !== id));
        //     } catch (error) {
        //         console.error("Error deleting registration:", error);
        //     }
        // }
        // // async function updateRegistrationById(id) {
        // //     try {
        // //         await axios.update(`http://localhost:8080/api/admin/users/${id}`);
        // //         navigate('/UpdateUsers');
        // //         setRegistration(registration.filter(registration => registration.id !== id));
        // //     } catch (error) {
        // //         console.error("Error updating registration:", error);
        // //     }
    
        // async function updateRegistrationById(id) {
        //     // const navigate = useNavigate();
        
        //     try {
                
        //         await axios.put(`http://localhost:8080/api/admin/users/${id}`, {
                   
        //         });
        
           
        //         navigate('/UpdateUsers');
        
              
        //         setRegistration(registration.filter(registration => registration.id !== id));
        //     } catch (error) {
        //         console.error("Error updating registration:", error);
        //     }
        // }
        
        return (
    
    
    <div>
            <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
              <a class="navbar-brand" >ADMIN</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              
              <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                <li class="nav-item">
              <Link to="/AllUsers" class="nav-link">All Users </Link>
              </li>
                  <li class="nav-item">
                  <Link to="/ListUsers" class="nav-link">Approved </Link>
                  </li>
                  <li class="nav-item">
                  <Link to="/PendingUsers" class="nav-link">Pending </Link>
                  </li>
              
              <li class="nav-item">
              <Link to="/RejectedUsers" class="nav-link">Rejected </Link>
              </li>
                </ul>
              </div>
            </div>
            </nav>
        
        
            <div className="container">
                <h2 className="text-center">Rejected Patients</h2>
    
                <table className="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Sl.No</th>
                            <th>Name</th>
                            <th>Date Of Birth</th>
                            <th>Email</th>
                            <th>Blood Group</th>
                            <th>Emergency Contact Number</th>
                            {/* <th>Actions</th> */}
                        </tr>
                    </thead>
                    <tbody>
                        {registration.map((registration ,index)=>(
                            <tr key={registration.id}>
                                <td>{index+1}</td>
                                <td>{registration.users.name}</td>
                                <td>{registration.dateOfBirth}</td>
                                <td>{registration.users.email}</td>
                                <td>{registration.bloodGroup}</td>
                                <td>{registration.emergencyContactNumber}</td>
                                 {/* <td style={{ display: 'flex', gap: '8px' }}>
         <button type='submit' className='btn btn-primary btn-block'  onClick={() => updateRegistrationById(registration.id)}            >UPDATE </button> 
        <button type='submit' className='btn btn-danger btn-block' onClick={() => deleteRegistrationById(registration.id)}>DELETE</button></td>  */}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            </div>)}

export default RejectedUsers