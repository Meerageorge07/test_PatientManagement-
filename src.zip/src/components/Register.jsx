
import { useState } from "react";
import { useNavigate } from 'react-router-dom';
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';

function Register() {

const[name,setName]=useState("");
const[dateOfBirth,setDateOfBirth]=useState("");
const[address,setAddress]=useState("");
const[email,setEmail]=useState("");
const[gender,setGender]=useState("");
const[bloodGroup,setBloodGroup]=useState("");
const[password,setPassword]=useState("");
const[department,setDepartment]=useState("");
const[emergencyContactName,setEmergencyContactName]=useState("");
const[emergencyContactNumber,setEmergencyContactNumber]=useState("");
const[relationship,setRelationship]=useState("");


const navigate=useNavigate();
const [emailError, setEmailError] = useState(""); 
const [PasswordError, setPasswordError] = useState(""); 
const[emergencyContactNameError,SetemergencyContactNameError]=useState("");
const[emergencyContactNumberError,SetemergencyContactNumberError]=useState("");
const [nameError, setNameError] = useState("");
const[dateOfBirthError, setdateOfBirthError]= useState("");
const[genderError, setGenderError]= useState("");
const[departmentError,setDepartmentError]=useState("");


async function save(event){
  event.preventDefault();
  let isValid = true;
        
        if (!name) {
            setNameError("Name is required");
            isValid = false;
        } else {
            setNameError("");
        }
        if (!dateOfBirth) {
          setdateOfBirthError("Date of Birth is required");
          isValid = false;
      } else {
          setdateOfBirthError("");
      }
      if (!gender) {
        setGenderError("Gender is required");
        isValid = false;
    } else {
        setGenderError("");
    }
    if (!password) {
      setPasswordError("Password is required");
      isValid = false;
  } else {
      setPasswordError("");
  }
  if (!email) {
    setEmailError("Email is required");
    isValid = false;
} else {
    setEmailError("");
}
if (!department) {
  setDepartmentError("Department is required");
  isValid = false;
} else {
  setDepartmentError("");
}
if (!emergencyContactName) {
  SetemergencyContactNameError("Emeregency Name is required");
  isValid = false;
} else {
  SetemergencyContactNameError("");
}
if (!emergencyContactNumber) {
  SetemergencyContactNumberError("Emeregency Number is required");
  isValid = false;
} else {
  SetemergencyContactNumberError("");
}
        if (!isValid) {
          return;
      }
  try{
    await axios.post("http://localhost:8080/api/registration",{
      name:name,
      dateOfBirth:dateOfBirth,
      email:email,
      bloodGroup:bloodGroup,
      address:address,
      department:department,
      password:password,
      gender:gender,
      emergencyContactName:emergencyContactName,
      emergencyContactNumber:emergencyContactNumber,
      relationship:relationship
   } ) ;
  
   toast.success("Registration successful");
   setTimeout(() => navigate('/'), 1000);

  }catch (err){
    toast.error("email already exists");
  }
  if (!name || !email || !dateOfBirth || !address || !gender || !emergencyContactName || !password || !emergencyContactNumber) {
  
    setNameError(name ? "" : "Name is required");
    setEmailError(email ? "" : "Email is required");
    setdateOfBirthError(dateOfBirth ? "" : "Date of Birth is required");
    setGenderError(gender ? "" : "Gender is required");
    setPasswordError(password ? "" : "Password is required");
    SetemergencyContactNameError(emergencyContactName ?"":"emergency contact is required")
    return;

}
}




    return (

      <div>
            
           
            <div className="row d-flex align-items-center justify-content-center mt-5 mb-5">
            <ToastContainer position="top-center" />
<div class="row d-flex align-items-center justify-content-center">
    <div class="col-md-7  p-3"> 
    <h2 >Patient Details</h2>
        <form  >

<div class="form-group">
  <label>Name</label>
  <input type="text"  class="form-control"  id="name" 
 maxLength="40"
value={name}
onChange={(event) =>{
  setName(event.target.value);


}}>
</input>
{nameError && <small className="text-danger">{nameError}</small>}
</div>
  
       
       
          
           

           <div class="form-group">
               <div class="mt-3">
                   <label  class="control-label">Date Of Birth*</label>
               <input  type="date"  id="dateOfBirth" class="form-control" name="DateOfBirth"  
               
value={dateOfBirth}
onChange={(event) =>{
  setDateOfBirth(event.target.value);


}}/>

{dateOfBirthError && <small className="text-danger">{dateOfBirthError}</small>}
           </div> </div>
 
   
           <div class="form-group">
               <div class="mt-3">
                   <label  class="control-label" >Gender</label>
                   <input
            type="radio"
            id="male"
            name="gender"
            value="male"
            onChange={(event) => setGender(event.target.value)}
            className="form-check-input"
        />
        <label className="form-check-label">Male</label>
    
    
        <input
            type="radio"
            id="female"
            name="gender"
            value="female"
            onChange={(event) => setGender(event.target.value)}
            className="form-check-input"
        />
        <label className="form-check-label">Female</label>
    </div>
    {genderError && <small className="text-danger">{genderError}</small>}
   </div>

          
           <div class="form-group">
               <div class="mt-3">
                   <label  class="control-label">Address</label>
               <textarea  type="text" class="form-control"   name="Address" id="address"
               
               value={address}
onChange={(event) =>{
  setAddress(event.target.value);


}}>
</textarea>
               
               </div>
           </div>


       <div class="mt-3">
           <div class="form-group">
                   <label  class="control-label">Email</label>
          

<input
type="email"
name="email"

className="form-control"
maxLength="40"
value={email}
onChange={(event) =>{
  setEmail(event.target.value);
  const isValidEmail = /\S+@\S+\.\S+/.test(event.target.value);
  if (!isValidEmail && event.target.value !== '') {
      setEmailError('Invalid email address');
  } else {
      setEmailError('');
  }
}}
  />
   {emailError && <small className="text-danger">{emailError}</small>} {/* Display email error */}
             
           </div>
       </div>
           
           <div class="mt-3">
               <div class="form-group">
                       <label for="bloodgroup">Blood Group</label>
                       <select className="form-control" value={bloodGroup} onChange={(event) => setBloodGroup(event.target.value)}>
                       <option value="" disabled >--Select--</option>
                               <option value="O-ve">O-ve</option>
                               <option value="O+ve">O+ve</option>
                               <option value="A+ve">A+ve</option>
                               <option value="A-ve">A-ve</option>
                               <option value="B+ve">B+ve</option>
                               <option value="B-ve">B-ve</option>
                               <option value="AB+Ve">AB+ve</option>
                               <option value="AB-Ve">AB-ve</option>
                       
                       </select>
                         
              </div> </div>


           <div class="mt-3">
           <div class="form-group">
               <label for="Department">Department </label>
                   {/* <select name="Department" id="department"  class="form-control"  > */}
                   <select className="form-control" value={department} onChange={(event) => setDepartment(event.target.value)}>
                   <option value="" disabled >--Select--</option>
                       <option value="General OP">General OP</option>
                       <option value="Neurology">Neurology</option>
                       <option value="Opthalmology">Opthalmology</option>
                       <option value="Gynaecology">Gynaecology</option>
                       <option value="ENT">ENT</option>
                       <option value="Cardiology">Cardiology</option>
                       <option value="Dermatology">Dermatology</option>
                   </select>
                  
               
       
               
                   {departmentError && <small className="text-danger">{departmentError}</small>}
           </div>
           </div>
           <div className="mt-3">
              <div className="form-group">
                <label className="control-label">Password</label>
                <input
                            type="password"
                            name="Password"
                            
                            className="form-control"
                            value={password}
onChange={(event) =>{
  setPassword(event.target.value);
  const isValidPassword = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{8,}$/.test(event.target.value);
if (!isValidPassword && event.target.value.trim() !== '') {
    setPasswordError('Password must be at least 8 characters long and should contain at least one uppercase letter, one lowercase letter, one number, and one special character');
} else {
    setPasswordError('');
}





}}
                        />
                         {PasswordError && <small className="text-danger">{PasswordError}</small>} {/* Display password error */}
                    </div></div>
           <br />
           <h2>Emergency Contact Details</h2>
           <br />
           <div class="form-group">
               <div class="mt-3">
                   <label class="control-label">Emergency Contact Name</label>
                   <input  class="form-control" id="emergencyContactName"   name="EmergencyContactName"
                   
                   value={emergencyContactName}
onChange={(event) =>{
  setEmergencyContactName(event.target.value);


}}>
</input>
                   
{emergencyContactNameError && <small className="text-danger">{emergencyContactNameError}</small>}

           </div>
           </div>

           <div class="form-group">
               <div class="mt-3">
                   <label  class="control-label">Emergency Contact Number</label>
                   <input
                            inputMode="numeric"
                            name="contactNumber"
                           
                            className="form-control"
                            maxLength="10"
                            onInput={(event) => event.target.value = event.target.value.replace(/\D+/g, '')}
                            value={emergencyContactNumber}
onChange={(event) =>{
  setEmergencyContactNumber(event.target.value);
  const isValidNumber = /^\d{10}$/.test(event.target.value);
  if (!isValidNumber && event.target.value !== '') {
    SetemergencyContactNumberError('contact number must contain exactly 10 digits');
  } else {
    SetemergencyContactNumberError('');
  }


}}
                        />
                         {emergencyContactNumberError && <small className="text-danger">{emergencyContactNumberError}</small>} {/* Display email error */}

           
              
              

           </div>
               </div>

           <div class="mt-3">
               <div class="form-group">
                   <label  class="control-label">Relationship</label>
                   <input type="text"id="relationship" class="form-control"   name="Relationship" 

               value={ relationship}
               onChange={(event) =>{
                 setRelationship(event.target.value);
               
               
               }}>
               </input>
                   
                   

               </div>
           </div>

<button type="submit" class="btn btn-primary btn-block"  onClick={save}>Register</button>

        </form>
        </div></div></div>  </div>
    );
  }
  
  export default Register;