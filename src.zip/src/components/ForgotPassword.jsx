import React from 'react';
import axios from "axios";
import { useState } from "react";
import { toast, ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';

const ForgotPassword = () => {

    const[email,setEmail]=useState("");

    async function send(event){
        event.preventDefault();
        try{
          await axios.post("http://localhost:8080/email",{
          email:email,
         } ) ;
         toast.success("successful");
        }catch (err){
          toast.error("not registered email id");
        }
      }
      




  return (
    <div>
      <div className="row d-flex align-items-center justify-content-center mt-5 mb-5">
            <ToastContainer position="top-center" />
    <div class="row d-flex align-items-center justify-content-center">
    <div class="col-md-5  p-3">

        <p class="text-center-align-left"> Forgot your password? Please enter your registered Email address and we will send a reset code via Email</p>

        <div class="mt-3">
            <form >
            <div  class="text-danger"></div>
            <div class="form-group">
                <div class="mt-4">
                <label  class="control-label">Email</label>
                <input class="form-control" 
                value={email}
                       
                onChange={(event) =>{
                 setEmail(event.target.value);
               
               
               }}>
               </input>
       
                

               
                    </div>
                </div>
        
                <div class="mt-3 mb-1">
                        <input type="submit" value="Continue" class="btn btn-primary btn-block"  onClick={send} />
                    </div>
                
        </form>
    </div>
</div>
</div></div></div>
  )
}

export default ForgotPassword