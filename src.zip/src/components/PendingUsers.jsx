import React from 'react';
import { Link} from 'react-router-dom';
import  { useState,useEffect } from 'react';
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';


const PendingUsers = () => {

const[registration,setRegistration]=useState([]);



useEffect(() => {
    async function fetchRegistration() {
        try {
            const response = await axios.get("http://localhost:8080/api/admin/pendingUsers");
            setRegistration(response.data);
        } catch (error) {
            console.error("Error fetching registrations:", error);
        }
    }

    fetchRegistration();
}, []);
async function approveRegistrationById(id) {
    try {
        const userConfirmed = window.confirm("Are you sure you want to approve this registration?");
        if (userConfirmed) {
            await axios.put(`http://localhost:8080/api/admin/${id}/approve`);
            setRegistration(registration.filter(reg => reg.id !== id));
            toast.success("patient is approved!");
        }
    } catch (error) {
        console.error("Error approving registration:", error);
        toast.error("Error approving item. Please try again later.");
    }
}
async function rejectRegistrationById(id) {
    try {
        const userConfirmed = window.confirm("Are you sure you want to reject this registration?");
        if (userConfirmed) {
            await axios.put(`http://localhost:8080/api/admin/${id}/reject`);
            setRegistration(registration.filter(reg => reg.id !== id));
            toast.success("Item rejected successfully!");
        }
    } catch (error) {
        console.error("Error rejecting registration:", error);
        toast.error("Error rejecting item. Please try again later.");
    }
}

  return (
    <div>
  <nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">ADMIN</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      
      <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
            <li class="nav-item">
          <Link to="/AllUsers" class="nav-link">All Users </Link>
          </li>
              <li class="nav-item">
              <Link to="/ListUsers" class="nav-link">Approved </Link>
              </li>
              <li class="nav-item">
              <Link to="/PendingUsers" class="nav-link">Pending </Link>
              </li>
              <li class="nav-item">
              <Link to="/RejectedUsers" class="nav-link">Rejected </Link>
              </li>
             
            </ul>
      </div>
    </div>
    </nav>


    
            <ToastContainer position="top-center" />
    <div className="container">
            <h2 className="text-center">Pending Patients</h2>

            <table className="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Sl.No</th>
                        <th>Name</th>
                        <th>Date Of Birth</th>
                        <th>Email</th>
                        <th>Blood Group</th>
                        <th>Emergency Contact Number</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {registration.map((registration,index) =>(
                        <tr key={registration.id}>
                            <td>{index+1}</td>
                            <td>{registration.users.name}</td>
                            <td>{registration.dateOfBirth}</td>
                            <td>{registration.users.email}</td>
                            <td>{registration.bloodGroup}</td>
                            <td>{registration.emergencyContactNumber}</td>
                            <td style={{ display: 'flex', gap: '8px' }}>
    <button type='submit' className='btn btn-primary btn-block'  onClick={() => approveRegistrationById(registration.id)}            >Approve </button>
    <button type='submit' className='btn btn-danger btn-block' onClick={() => rejectRegistrationById(registration.id)}>Reject</button></td>
                        
                        
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>







  </div>
  )
}

export default PendingUsers