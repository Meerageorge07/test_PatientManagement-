import React, { useState,useEffect } from 'react';
import { useNavigate,Link } from 'react-router-dom';
import axios from "axios";

const ListUsers = () => {
    const[registration,setRegistration]=useState([]);
  
const navigate=useNavigate();

    useEffect(() => {
        async function fetchRegistration() {
            try {
                const response = await axios.get("http://localhost:8080/api/admin/display");
                setRegistration(response.data);
            } catch (error) {
                console.error("Error fetching registrations:", error);
            }
        }

        fetchRegistration();
    }, []);




    async function deleteRegistrationById(id) {
        try {
            await axios.delete(`http://localhost:8080/api/admin/${id}`);
            setRegistration(registration.filter(registration => registration.id !== id));
        } catch (error) {
            console.error("Error deleting registration:", error);
        }
    }
 
    return (


<div>
        <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
          <a class="navbar-brand" >ADMIN</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
            <li class="nav-item">
          <Link to="/AllUsers" class="nav-link">All Users </Link>
          </li>
              <li class="nav-item">
              <Link to="/ListUsers" class="nav-link">Approved </Link>
              </li>
              <li class="nav-item">
              <Link to="/PendingUsers" class="nav-link">Pending </Link>
              </li>
              <li class="nav-item">
              <Link to="/RejectedUsers" class="nav-link">Rejected </Link>
              </li>
             
            </ul>
          </div>
        </div>
        </nav>
    
    
        <div className="container">
            <h2 className="text-center">Approved Patients</h2>

            <table className="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Sl.No</th>
                        <th>Name</th>
                        <th>Date Of Birth</th>
                        <th>Email</th>
                        <th>Blood Group</th>
                        <th>Emergency Contact Number</th>
                        {/* <th>Actions</th> */}
                    </tr>
                </thead>
                <tbody>
                    {registration.map((registration,index) =>(
                        <tr key={registration.id}>
                            <td>{index+1}</td>
                            <td>{registration.users.name}</td>
                            <td>{registration.dateOfBirth}</td>
                            <td>{registration.users.email}</td>
                            <td>{registration.bloodGroup}</td>
                            <td>{registration.emergencyContactNumber}</td>
                           
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
        </div>
    )
}


export default ListUsers;