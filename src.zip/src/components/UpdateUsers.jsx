import React, { useState, useEffect } from 'react';
import axios from 'axios';

const UpdateUsers = () => {
    const [userDetails, setUserDetails] = useState({
        name: "",
        // dateOfBirth: "",
        // address: "",
        email: "",
        password: "",
        // emergencyContactName: "",
        // emergencyContactNumber: "",
        // relationship: ""
    });

    const [emailError, setEmailError] = useState(""); 
    const [passwordError, setPasswordError] = useState(""); 
    
    useEffect(() => {
        // Fetch user details from the backend when the component mounts
        const fetchUserDetails = async () => {
            try {
                const response = await axios.get("http://localhost:8080/api/admin/users/id"); // Adjust the endpoint URL accordingly
                const userData = response.data;
                setUserDetails(userData);
            } catch (error) {
                console.error('Error fetching user details:', error);
            }
        };

        fetchUserDetails();
    }, []);

    const validateEmail = (email) => {
        // Basic email validation
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    };

    const validatePassword = (password) => {
        // Password length validation
        return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(password);
    };

    async function save(event) {
        event.preventDefault();

        if (!validateEmail(userDetails.email)) {
            setEmailError("Invalid email format");
            return;
        }
        if (!validatePassword(userDetails.password)) {
            setPasswordError("Password must be at least 8 characters long, containing at least 1 capital letter, 1 small letter, 1 digit, and 1 special character");
            return;
        }

        try {
            await axios.post("http://localhost:8080/api/updateUserDetails", userDetails);
            alert("Details updated successfully");
        } catch (err) {
            console.error('Error updating details:', err);
            alert("Error updating details");
        }
    }

    const handleInputChange = (event) => {
        setUserDetails({ ...userDetails, [event.target.name]: event.target.value });
    };

    return (
        <div>
            <div className="row d-flex align-items-center justify-content-center">
                <div className="col-md-7 p-3">
                    <h2>Update Details</h2>
                    <form>
                        <div className="form-group">
                            <label>Name</label>
                            <input
                                type="text"
                                className="form-control"
                                name="name"
                                value={userDetails.name}
                                onChange={handleInputChange}
                            />
                        </div>

                        <div className="form-group">
                            <div className="mt-3">
                                <label className="control-label">Email</label>
                                <input
                                    type="date"
                                    className="form-control"
                                    name="email"
                                    value={userDetails.email}
                                    onChange={handleInputChange}
                                />
                            </div>
                        </div>

                        <div className="form-group">
                            <div className="mt-3">
                                <label className="control-label">password</label>
                                <input
                                    type="date"
                                    className="form-control"
                                    name="password"
                                    value={userDetails.password}
                                    onChange={handleInputChange}
                                />
                            </div>
                        </div>
                       
                        <button type="submit" className="btn btn-primary btn-block" onClick={save}>Update</button>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default UpdateUsers;
