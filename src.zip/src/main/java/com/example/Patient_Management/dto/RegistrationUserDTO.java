package com.example.Patient_Management.dto;

import com.example.Patient_Management.enums.ApprovalStatus;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;

import java.time.LocalDate;

public class RegistrationUserDTO {
    private String name;
    private String email;

    private  String  password;
    private  String role;
    private LocalDate dateOfBirth;
    private String gender;
    private String address;

    private  String  bloodGroup;
    private  String department;
    private String emergencyContactName;
    private  String emergencyContactNumber;
    private  String relationship;
//    @Enumerated(EnumType.STRING)
//private ApprovalStatus approvalStatus;

    public RegistrationUserDTO(String name, String email, String password, String role, LocalDate dateOfBirth, String gender, String address, String bloodGroup, String department, String emergencyContactName, String emergencyContactNumber, String relationship, ApprovalStatus approvalStatus) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
        this.dateOfBirth = dateOfBirth;
        this.gender = gender;
        this.address = address;
        this.bloodGroup = bloodGroup;
        this.department = department;
        this.emergencyContactName = emergencyContactName;
        this.emergencyContactNumber = emergencyContactNumber;
        this.relationship = relationship;
//        this.approvalStatus = approvalStatus;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getEmergencyContactName() {
        return emergencyContactName;
    }

    public void setEmergencyContactName(String emergencyContactName) {
        this.emergencyContactName = emergencyContactName;
    }

    public String getEmergencyContactNumber() {
        return emergencyContactNumber;
    }

    public void setEmergencyContactNumber(String emergencyContactNumber) {
        this.emergencyContactNumber = emergencyContactNumber;
    }

    public String getRelationship() {
        return relationship;
    }

    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }

//    public ApprovalStatus getApprovalStatus() {
//        return approvalStatus;
//    }
//
//    public void setApprovalStatus(ApprovalStatus approvalStatus) {
//        this.approvalStatus = approvalStatus;
//    }
}
