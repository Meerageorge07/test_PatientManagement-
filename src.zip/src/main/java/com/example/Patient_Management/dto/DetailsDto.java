package com.example.Patient_Management.dto;
import com.example.Patient_Management.entity.Registration;
import com.example.Patient_Management.entity.users;
public class DetailsDto {
    private  users users;
    private  Registration registration;

    public DetailsDto() {

    }

    public users getUsers() {
        return users;
    }

    public void setUsers(users users) {
        this.users = users;
    }

    public Registration getRegistration() {
        return registration;
    }

    public void setRegistration(Registration registration) {
        this.registration = registration;
    }

    public DetailsDto(users users, Registration registration) {
        this.users = users;
        this.registration = registration;
    }
}
