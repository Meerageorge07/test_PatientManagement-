package com.example.Patient_Management.service.Interface;

import com.example.Patient_Management.dto.resetPasswordDto;
import com.example.Patient_Management.entity.users;

public interface EmailService {
    public boolean forgotPassword(String email) ;
    users resetPassword(resetPasswordDto resetPasswordDto );
}
