package com.example.Patient_Management.service.Interface;

import com.example.Patient_Management.dto.RegistrationUserDTO;

public interface loginService {
//    boolean login(RegistrationUserDTO registrationUserDTO);
   String login(RegistrationUserDTO registrationUserDTO);
//   boolean emailExists(String email);
}
