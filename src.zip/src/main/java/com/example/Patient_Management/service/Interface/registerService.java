package com.example.Patient_Management.service.Interface;

import com.example.Patient_Management.dto.RegistrationUserDTO;

import com.example.Patient_Management.entity.Registration;
import org.springframework.stereotype.Service;

@Service
public interface registerService {

    Registration createPatient(RegistrationUserDTO registrationUserDTO);

  ;
}









