package com.example.Patient_Management.service.Impl;
import com.example.Patient_Management.dto.resetPasswordDto;
import com.example.Patient_Management.repository.usersRepo;
import com.example.Patient_Management.repository.registerRepo;
import com.example.Patient_Management.entity.users;
import com.example.Patient_Management.service.Interface.EmailService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@Transactional
public class PasswordResetServiceimpl implements EmailService {

    @Autowired
    private usersRepo usersRepo;
    @Autowired
    private registerRepo registerRepo;

    @Autowired
    private JavaMailSender emailSender;


@Transactional
    @Override
    public boolean forgotPassword(String email) {
        users users = usersRepo.findByEmail(email);
        if (users != null) {
            // Generate reset token
            String resetToken = generateResetToken();
            users.setResetToken(resetToken);

            usersRepo.save(users);

            // Construct the reset link
            String resetLink = "http://localhost:3000/ResetPassword?email=" + email + "&token=" + resetToken;


            // Send reset email
            sendResetEmail(email, resetLink);

            return true;
        }
        return false;
    }

    @Override
    public users resetPassword(resetPasswordDto resetPasswordDto ) {
        if (resetPasswordDto.getEmail() == null || resetPasswordDto.getResetToken() == null) {
            return null;
        }

        users registration = usersRepo.findByEmail(resetPasswordDto.getEmail());
        if (registration == null) {
            return null; // User not found
        }


        if (!resetPasswordDto.getResetToken().equals(registration.getResetToken()) ){

            return null;

        }
        registration.setPassword(resetPasswordDto.getNewpassword());
        return usersRepo.save(registration);


    }





    private String generateResetToken() {
        return UUID.randomUUID().toString();
    }

    private void sendResetEmail(String email, String resetLink) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom("meeravattappalam40@gmail.com");
        message.setTo(email);
        message.setSubject("Password Reset");
        message.setText("Click the following link to reset your password: " + resetLink);

        emailSender.send(message);
    }
   }




