package com.example.Patient_Management.service.Interface;

public interface deleteService {



    boolean deleteUserById(Long id);
}
