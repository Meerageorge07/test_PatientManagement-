package com.example.Patient_Management.service.Interface;

import com.example.Patient_Management.entity.Registration;
import com.example.Patient_Management.enums.ApprovalStatus;

import java.util.List;

public interface ApprovalService {



//    void approveRegistration(Long id);
//    void rejectRegistration(Long id);
//Registration approvalRequest(Long id, ApprovalStatus approvalStatus);

    Registration rejectRegistration(Long id);
    Registration approveRegistration(Long id);
    List<Registration> getPendingApprovalUser();
    List<Registration> getApprovalUser();
    List<Registration> getRejectUser();
   // Registration approveRequest(Long id, ApprovalStatus approvalStatus);
}
