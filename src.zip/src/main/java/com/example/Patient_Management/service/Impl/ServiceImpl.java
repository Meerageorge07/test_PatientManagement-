package com.example.Patient_Management.service.Impl;

import com.example.Patient_Management.dto.RegistrationUserDTO;

import com.example.Patient_Management.entity.Registration;
import com.example.Patient_Management.entity.users;
import com.example.Patient_Management.enums.ApprovalStatus;
import com.example.Patient_Management.repository.registerRepo;
import com.example.Patient_Management.repository.usersRepo;
import com.example.Patient_Management.service.Interface.*;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;


@Service
@Transactional
public class ServiceImpl implements registerService, loginService, viewService, updateService, deleteService, ApprovalService {


    @Autowired
   private  usersRepo usersRepo;
    @Autowired
    private registerRepo registerRepo;




    @Override
    public Registration createPatient(RegistrationUserDTO registrationUserDTO) {
        if (usersRepo.existsByEmail(registrationUserDTO.getEmail())) {
            return null; // Email already exists
        }
        users users = new users();
        users.setName(registrationUserDTO.getName());
        users.setEmail(registrationUserDTO.getEmail());
        users.setPassword(registrationUserDTO.getPassword());
        users.setRole("2");

        usersRepo.save(users);

        Registration registration = new Registration();
        registration.setGender(registrationUserDTO.getGender());
        registration.setEmergencyContactNumber(registrationUserDTO.getEmergencyContactNumber());
        registration.setUsers(users);
        registration.setBloodGroup(registrationUserDTO.getBloodGroup());
        registration.setRelationship(registrationUserDTO.getRelationship());
        registration.setDepartment(registrationUserDTO.getDepartment());
        registration.setEmergencyContactName(registrationUserDTO.getEmergencyContactName());
        registration.setDateOfBirth(registrationUserDTO.getDateOfBirth());
        registration.setAddress(registrationUserDTO.getAddress());
        registration.setApprovalStatus("pending");

        return     registerRepo.save(registration);

    }

    @Override
    public List<Registration> getAllUsers() {
        return registerRepo.findAll();
    }

    @Override
    public Registration getUserById(Long id) {
        return  registerRepo.findById(id).orElse(null);
    }



    @Override
    public Registration updateUser(Long id, RegistrationUserDTO registrationUserDTO) {

      Registration exisitingUser= registerRepo.findById(id).orElse(null);

      if(exisitingUser!=null){
        exisitingUser.setAddress(registrationUserDTO.getAddress());
        exisitingUser.setDepartment(registrationUserDTO.getDepartment());
        exisitingUser.setRelationship(registrationUserDTO.getRelationship());
        exisitingUser.setGender(registrationUserDTO.getGender());
        exisitingUser.setDateOfBirth(registrationUserDTO.getDateOfBirth());
        exisitingUser.setEmergencyContactNumber(registrationUserDTO.getEmergencyContactNumber());
        exisitingUser.setEmergencyContactName(registrationUserDTO.getEmergencyContactName());
        exisitingUser.setBloodGroup(registrationUserDTO.getBloodGroup());

        registerRepo.save(exisitingUser);


       exisitingUser.getUsers().setPassword(registrationUserDTO.getPassword());
       exisitingUser.getUsers().setName(registrationUserDTO.getName());
       exisitingUser.getUsers().setEmail(registrationUserDTO.getEmail());

       usersRepo.save(exisitingUser.getUsers());
          return exisitingUser;
    }
      return null;

    }


    @Override
    public boolean deleteUserById(Long id) {
        {
            if (registerRepo.existsById(id)) {
                registerRepo.deleteById(id);
                return true;
            }
            return false;
        }

}


    @Override
    public Registration rejectRegistration(Long id) {
        Registration registration = registerRepo.findById(id).orElse(null);
        if (registration != null) {
            registration.setApprovalStatus("Rejected");
            registerRepo.save(registration);
        }
        return null;
    }


    @Override
    public Registration approveRegistration(Long id) {
        Registration registration = registerRepo.findById(id).orElse(null);
        if (registration != null) {
            registration.setApprovalStatus("Approved");
            registerRepo.save(registration);
        }
        return null;
    }

    @Override
    public List<Registration> getPendingApprovalUser() {
        return registerRepo.findByApprovalStatus("pending");
    }

    @Override
    public List<Registration> getApprovalUser() {
        return registerRepo.findByApprovalStatus( "Approved");
    }

    @Override
    public List<Registration> getRejectUser() {
        return registerRepo.findByApprovalStatus("rejected");
    }


    @Override
    public String login(RegistrationUserDTO registrationUserDTO) {
        users userExist = usersRepo.findByEmail(registrationUserDTO.getEmail());

        if (userExist != null) {
            if (userExist.getPassword().equals(registrationUserDTO.getPassword())) {
                String role = userExist.getRole();

                if ("1".equals(role)) {

                    return "user is admin";
                } else if ("2".equals(role)) {

                    return "user is a normal user";
                }
            }
        }

        return "invalid";
    }


}









