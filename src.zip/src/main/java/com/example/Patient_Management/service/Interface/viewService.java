package com.example.Patient_Management.service.Interface;

import com.example.Patient_Management.entity.Registration;


import java.util.List;

public interface viewService {




    List<Registration>getAllUsers();
    Registration getUserById(Long id);


}
