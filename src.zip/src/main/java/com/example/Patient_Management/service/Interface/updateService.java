package com.example.Patient_Management.service.Interface;

import com.example.Patient_Management.dto.RegistrationUserDTO;
import com.example.Patient_Management.entity.Registration;

public interface updateService {

   Registration updateUser(Long id, RegistrationUserDTO registrationUserDTO);
}
