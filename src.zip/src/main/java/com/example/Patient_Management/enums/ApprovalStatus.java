package com.example.Patient_Management.enums;

public enum ApprovalStatus {
    pending,
    Approved,
    Rejected;



}
