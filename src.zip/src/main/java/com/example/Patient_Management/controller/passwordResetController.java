package com.example.Patient_Management.controller;
import com.example.Patient_Management.dto.resetPasswordDto;
import com.example.Patient_Management.service.Interface.registerService;
import com.example.Patient_Management.entity.Registration;
import com.example.Patient_Management.entity.users;
import com.example.Patient_Management.service.Impl.PasswordResetServiceimpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@CrossOrigin
@RequestMapping
@RestController

public class passwordResetController {

        @Autowired
        private PasswordResetServiceimpl passwordResetServiceimpl;
    @Autowired
    private registerService registerService;

    @PostMapping("/email")
    public ResponseEntity<String> forgotPassword(@RequestBody users users) {
        boolean success =passwordResetServiceimpl.forgotPassword(users.getEmail());
        if (success) {
            return ResponseEntity.ok("Password reset email sent successfully");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
        }

    }

//    @PostMapping("/resetToken")
//    public ResponseEntity<String> resetPassword(@RequestBody resetPasswordDto resetpassworddto) {
//        // Call the resetPassword method from the service
//        if (!resetpassworddto.getNewpassword().equals(resetpassworddto.getConfirmpassword())) {
//            return ResponseEntity.badRequest().body("New password and confirm password do not match");
//        }
//
//        users registration = passwordResetServiceimpl.resetPassword(resetpassworddto);
//
//        if (registration != null) {
//            return ResponseEntity.ok("Password reset successfully");
//        } else {
//            return ResponseEntity.badRequest().body("Invalid email or reset token");
//        }
//    }



}

