package com.example.Patient_Management.controller;

import com.example.Patient_Management.dto.RegistrationUserDTO;
import com.example.Patient_Management.entity.Registration;
import com.example.Patient_Management.enums.ApprovalStatus;
import com.example.Patient_Management.service.Interface.ApprovalService;
import com.example.Patient_Management.service.Interface.viewService;
import com.example.Patient_Management.service.Interface.deleteService;
import com.example.Patient_Management.service.Interface.updateService;
import com.example.Patient_Management.service.Interface.registerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin
@RestController
@RequestMapping("/api/admin")

public class AdminController {
    @Autowired
    private viewService viewService;
    @Autowired
    private updateService updateService;
    @Autowired
    private deleteService deleteService;
    @Autowired
    private ApprovalService approvalService;
    @Autowired
    private registerService registerService;

 @GetMapping("/display")
 public ResponseEntity<List<Registration>> getAllUsers() {
     List<Registration> details = viewService.getAllUsers();
     return ResponseEntity.ok(details);
 }



    @GetMapping("/display/{id}")

    public ResponseEntity<Registration> getUserById(@PathVariable Long id) {
        Registration user = viewService.getUserById(id);
        if (user != null) {
            return new ResponseEntity<>(user, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

    }



    @PutMapping("/users/{id}")
    public ResponseEntity<Registration> updateUser(@PathVariable("id") Long Id, @RequestBody RegistrationUserDTO registrationUserDTO) {
       Registration  updatedDetails = updateService.updateUser(Id, registrationUserDTO);

            return ResponseEntity.ok(updatedDetails);



        }
        @DeleteMapping("/{id}")
        public ResponseEntity<String> deleteUserById(@PathVariable Long id) {
            boolean deleted = deleteService.deleteUserById(id);
            if (deleted) {
                return ResponseEntity.ok("User deleted successfully");
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
            }
        }


    @GetMapping("/pendingUsers")
    public ResponseEntity<List<Registration>> getPendingApprovalUser() {
        List<Registration> details = approvalService.getPendingApprovalUser();
        return ResponseEntity.ok(details);
    }
    @GetMapping("/approvedUsers")
    public ResponseEntity<List<Registration>> getApprovalUser() {
        List<Registration> details = approvalService.getApprovalUser();
        return ResponseEntity.ok(details);
    }
    @GetMapping("/rejectedusers")
    public ResponseEntity<List<Registration>> getRejectedUsers() {
        List<Registration> details = approvalService.getRejectUser();
        return ResponseEntity.ok(details);
    }


//        @PutMapping("/{id}/status")
//        public ResponseEntity<Registration> approvalRequest(@PathVariable Long id, @RequestParam ApprovalStatus approvalStatus) {
//            Registration updated = approvalService.approvalRequest(id, approvalStatus);
////            if (updated!= null) {
//            return ResponseEntity.ok(updated);
//        }
@PutMapping("/{id}/reject")
public ResponseEntity<Registration> rejectRegistration(@PathVariable Long id) {
    Registration registeration=approvalService.rejectRegistration(id);
    return ResponseEntity.ok(registeration);
}
    @PutMapping("/{id}/approve")
    public ResponseEntity<Registration> approveRegistration(@PathVariable Long id) {
        Registration registeration=approvalService.approveRegistration(id);
        return ResponseEntity.ok(registeration);
    }
}



