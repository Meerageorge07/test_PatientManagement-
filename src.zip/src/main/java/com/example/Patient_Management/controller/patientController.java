package com.example.Patient_Management.controller;
import com.example.Patient_Management.dto.RegistrationUserDTO;

import com.example.Patient_Management.entity.Registration;
import com.example.Patient_Management.service.Interface.registerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/api/registration")
public class patientController {




        @Autowired
        private registerService registerService;

        @PostMapping
        public ResponseEntity<?> createPatient(@RequestBody RegistrationUserDTO registrationUserDTO) {
            Registration register = registerService.createPatient(registrationUserDTO);
            if (register != null) {
                return new ResponseEntity<>(register, HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>("Email already exists", HttpStatus.BAD_REQUEST);
            }
        }




    }









