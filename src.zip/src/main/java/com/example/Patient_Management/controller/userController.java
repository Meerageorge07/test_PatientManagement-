package com.example.Patient_Management.controller;

import com.example.Patient_Management.dto.RegistrationUserDTO;
import com.example.Patient_Management.service.Interface.loginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/api/user")
public class userController {

    @Autowired
private loginService loginService;



    @PostMapping("/login")

    public String login(@RequestBody RegistrationUserDTO registrationUserDTO) {
        String loginResult = loginService.login(registrationUserDTO);
        return loginResult;
    }


    }


