package com.example.Patient_Management.repository;


import com.example.Patient_Management.entity.Registration;
import com.example.Patient_Management.entity.users;
import com.example.Patient_Management.enums.ApprovalStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface registerRepo extends JpaRepository<Registration,Long> {

    Registration findByusers(users user);

    List<Registration> findByApprovalStatus(String approvalStatus);


}