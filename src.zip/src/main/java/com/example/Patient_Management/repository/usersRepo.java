package com.example.Patient_Management.repository;


import com.example.Patient_Management.entity.users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface usersRepo  extends JpaRepository<users,Long>{


    static boolean findById() {
        return false;
    }

    users findByEmail(String email);


    boolean existsByEmail(String email);
}