package com.example.Patient_Management.entity;

import com.example.Patient_Management.enums.ApprovalStatus;
import jakarta.persistence.*;

import java.time.LocalDate;


@Entity
@Table(name="Registration")
public class Registration {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="Id")
    private Long id;
    @Column(name="DateOfBirth")
    private LocalDate dateOfBirth;
    @Column(name="Gender")
    private String gender;
    @Column(name="Address")
    private String address;
    @Column(name="BloodGroup")
    private String bloodGroup;
    @Column(name="Department")
    private String department;
    @Column(name="EmergencyContactName")
    private String emergencyContactName;
    @Column(name="EmergencyContactNumber")
    private String emergencyContactNumber;
    @Column(name = "Relationship", nullable = true)
    private String relationship;
    @Column(name="ApprovalStatus")
//    @Enumerated(EnumType.STRING)
private String approvalStatus;



    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "User_Id",referencedColumnName = "Id" )
    private  users users;

    public Registration() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getEmergencyContactName() {
        return emergencyContactName;
    }

    public void setEmergencyContactName(String emergencyContactName) {
        this.emergencyContactName = emergencyContactName;
    }

    public String getEmergencyContactNumber() {
        return emergencyContactNumber;
    }

    public void setEmergencyContactNumber(String emergencyContactNumber) {
        this.emergencyContactNumber = emergencyContactNumber;
    }

    public String getRelationship() {
        return relationship;
    }

    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }


//    public ApprovalStatus getApprovalStatus() {
//        return ;
//    }


    public String getApprovalStatus() {
        return approvalStatus;
    }

    public void setApprovalStatus(String approvalStatus) {
        this.approvalStatus = approvalStatus;
    }

    public com.example.Patient_Management.entity.users getUsers() {
        return users;
    }

    public void setUsers(com.example.Patient_Management.entity.users users) {
        this.users = users;
    }

    public Registration(Long id, LocalDate dateOfBirth, String gender, String address, String bloodGroup, String department, String emergencyContactName, String emergencyContactNumber, String relationship, ApprovalStatus approvalStatus, com.example.Patient_Management.entity.users users) {
        this.id = id;
        this.dateOfBirth = dateOfBirth;
        this.gender = gender;
        this.address = address;
        this.bloodGroup = bloodGroup;
        this.department = department;
        this.emergencyContactName = emergencyContactName;
        this.emergencyContactNumber = emergencyContactNumber;
        this.relationship = relationship;
//        this.approvalStatus = approvalStatus;
        this.users = users;
    }

    public String getResetToken() {
        return null;
    }

    public void setPassword(String newPassword) {
    }

    public void setResetToken(Object o) {

    }
}

