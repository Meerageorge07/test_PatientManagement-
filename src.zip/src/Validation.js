// export default function Validation(email){
//     const errors={}

//     const email_pattern=/^[^/s@]+@[^/s@]+\.[^\s@]{2,6}$/;
// }