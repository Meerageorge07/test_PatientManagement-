
import Loginuser from "./components/Loginuser";

import {BrowserRouter,Routes,Route}from 'react-router-dom';
 import Register from "./components/Register";
import ListUsers from "./components/ListUsers";
import ForgotPassword from "./components/ForgotPassword";
import ResetPassword from "./components/ResetPassword";
import UpdateUsers from "./components/UpdateUsers";
import AdminPage from "./components/AdminPage";
import PendingUsers from "./components/PendingUsers";
import Home from "./components/Home";
import AllUsers from "./components/AllUsers";
import RejectedUsers from "./components/RejectedUsers";

function App() {
  return (
  <div>

<BrowserRouter>
<Routes>
<Route path="/"  element={ <Loginuser/>  }/>
  <Route path="/ListUsers" element={ <ListUsers/>  }/>
  <Route path="/register" element={ <Register/>  }/>
  <Route path="/ForgotPassword" element={ <ForgotPassword/>  }/>
  <Route path="/ResetPassword" element={ <ResetPassword/>  }/>
  <Route path="/UpdateUsers" element={ <UpdateUsers/>  }/>
  <Route path="/AdminPage" element={ <AdminPage/>  }/>
  <Route path="/PendingUsers" element={ <PendingUsers/>  }/>
  <Route path="/RejectedUsers" element={<RejectedUsers/>}/>
  <Route path="/AllUsers" element={<AllUsers /> }/>
  <Route path="/Home" element={ <Home/>  }/>
</Routes>

</BrowserRouter>

</div>
   
  );
}

export default App;
